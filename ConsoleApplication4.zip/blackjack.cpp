#include <iostream>
#include <Windows.h>
#include <vector>
#include <stdio.h>
#include <ctime>

#include "card.h"
#include "blackjack.h"

using namespace std;

Deck::Deck() {
    cards.resize (52);
    for (int i = 0; i < 52; i++)	{
        cards[i].set_suit (static_cast<Suit> (i / 13 + HEARTS));
        cards[i].set_rank (static_cast<Rank> (i % 13 + ACE));
    }
    top = 0;
    ndeck = 1;
}

Deck::Deck (int x) {
    cards.resize (52 * x);
    for (int i = 0; i < x * 52; i++)	{
        cards[i].set_suit (static_cast<Suit> (i / x / 13 + HEARTS));
        cards[i].set_rank (static_cast<Rank> (i / x % 13 + ACE));
    }
    top = 0;
    ndeck = x;
}

void Deck::shuffle() {
    srand (time (0));
    int f = ndeck * 52;
    for (int i = 0; i < 10000; i++)
        swap (cards[rand() % f], cards[rand() % f]);
    top = 0;
}

Card Deck::draw_card() {
    return cards[top++];
}

bool Deck::empty() {
    return top >= 52;
}

Player::Player (Deck& d) {
    Hand h;
    h.hit (d);
    h.hit (d);
    hands.push_back (h);
    money = 500;
    has_split = false;
}

void Hand::split_back (Card& card) {
    handcard.push_back (card);
}

void Player::splits (vector<Hand>& han, Deck& d) {
    if (han[0].getrank (0) != han[0].getrank (1)) return;
    else {
        Hand split;
        Card card ((Rank)3, (Suit)4);
        split.split_back (card);
        split.setcard (0, han[0][0]);
        split.hit (d);
        han[0].setcard (1, d.draw_card());    //have to give draw a new second card
        han.push_back (split);               //draws second card for split, hit() calls total();
        has_split = true;
    }
}

Hand& Player::operator[] (int x) {
    return hands[x];
}

vector<Hand>& Player::gethands() {
    return hands;
}

Hand::Hand() {
    ace = 0;
    score = 0;
    hascalled = false;
    folded = false;
    blackjack = false;
}

Card& Hand::operator[] (int x) {
    return handcard[x];
}

void Hand::setcard (int i, Card& x) {
    handcard[i] = x;
}

int Hand::getscore() {
    return score;
}

int Dealer::getscore() {
    return score;
}

void Hand::hit (Deck& d) {
    Card g = d.draw_card();
    if (g.get_rank() == ACE) ace += 1;
    handcard.push_back (g);
    total();
}

void Hand::total() {
    score = 0;
    int a = ace;
    for (int i = 0; i <= handcard.size() - 1; i++) {
        if (getrank (i) == 1) score += 11;
        else if (getrank (i) > 10) score += 10;
        else score += getrank (i);
        is_blackjack();
        if (score > 21)
            fold();
    }
    while (score > 21 && a > 0) {
        score -= 10;
        a--;
    }
}// Allows for multple aces to get reduced as score keeps going over 21.

int Hand::getrank (int i) {
    return handcard[i].get_rank();
}

void Hand::fold() {
    folded = true;
}

Dealer::Dealer (Deck& d) {
    dhit (d);
    dhit (d);
    ace = 0;
    score = 0;
    blackjack = false;
    bust = false;
}

void Dealer::dtotal() {
    for (int i = 0; i <= dhand.size() - 1; i++) {
        if (dhand[i].get_rank() == 1) score += 11;
        if (dhand[i].get_rank() >= 11) score += 10;
        score += dhand[i].get_rank();
        is_blackjack();
    }
}

void Dealer::dhit (Deck& d) {
    dhand.push_back (d.draw_card());
    dtotal();
}

int Game::winner() {
    return 0;
}

void Dealer::dealermove (Deck& d) {
    if (score >= 17)  ;  // if there's an ace above
    else { dhit (d); dealermove (d); }
}

int Hand::size() {
    return handcard.size();
}

int Player::size() {
    return hands.size();
}

void Hand::showhand() {
    for (int i = 0; i < size(); i++)
        handcard[i].display_card (20 + 3 * i, 0, false, true);
}

void Hand::showsplit (int x) {
    for (int i = 0; i < size(); i++)
        handcard[i].display_card (40 + 3 * i, x, false, true);
}

void Hand::call (int min) {
    bet_value = min;
    hascalled = true;
}

Game::Game (int x) {
    du = Deck (x);
    dealer = &Dealer (du);
    du.shuffle();
    for (int i = 0; i < x; i++)
        players.push_back (Player (du));
    player = 0;
    betting = true;
    min = 0;
    print_score();
}

Player& Game::operator[] (int x) {
    return players[x];
}

void Game::nextplayer() {
    if (player == players.size() - 1) {
        gotoxy (0, 4 + players.size() - 1);
        cout << "   ";
        gotoxy (0, 4);
        player = 0;
        cout << ">>";
    } else {
        gotoxy (0, 4 + player);
        cout << "   ";
        player++;
        gotoxy (0, 4 + player);
        cout << ">>";
    }
    for (int i = 0; i < 2; i++)
        players[0][0][0].display_card (20 + 3 * i, 0, false, false);
    if ((player > 0) && (players[player - 1].split()))	{
        for (int i = 0; i < 2; i++)
            players[0][0][0].display_card (40 + 3 * i, 0, false, false);
    }
}

int Player::get_money() {
    return money;
}

bool Player::split() {
    return has_split;
}

void Game::print_score() {
    gotoxy (3, 2);
    cout << "PLAYERS:" << endl;
    cout << "--------------------";
    gotoxy (3, 4);
    for (int i = 0; i < players.size(); i++) {
        cout << "P" << i + 1 << " " << players[i].get_money() << " ";
        if (players[i].split() == true) {
            for (int y = 0; y <= players[i].size() - 1;
                    y++) {  // check to see if it's in bettign mode and only displays the two split cards
                if (betting)
                    cout << players[i][y][0] << "CA";
                else for (int t = 0; t < players[i][y].size(); t++)
                        cout << players[i][y][t];
                cout << " ";
            }
        } else if (betting)
            cout << players[i][0][0] << "CA";
        else
            for (int t = 0; t < players[i][0].size(); t++)
                cout << players[i][0][t];
        cout << endl << "   ";
    }
}

bool Game::mode() {
    return betting;
}

int Hand::bet (int x) {
    return bet_value = x;
}

int Game::minbet() {
    return min;
}

Player& Game::get_in (int i) {
    return *player_in[i];
}

void Player::showhands() {
    if (split()) {
        hands[0].showhand();
        hands[1].showsplit (0);
        int h = hands.size();
        for (int i = 2; i < h; i++)
            hands[i].showsplit (i * 2);
    } else hands[0].showhand();
}

void Game::gameHand() {
    char c;
    gotoxy (0, 23);
    cout << "Press F + Enter to see your hand" << endl;
    cin >> c;
    if (c == 'f')
        players[player].showhands();
    else gameHand();
}

void Game::betTurn() {
    Player &p = players[player];
    char x;
    cin >> x;
    switch (x) {
        case ('s') :
            p.splits (p.gethands(), du);
            if (p.split())		{
                p.showhands();
                print_score();
                break;
            }
        /*      case('g'):

        if (t[0].split()){     // if player bets and everyone else has called
        t[0].bet(t[0][0], minbet()); //destroy player_in and recreate it with that player first
        t[0].bet(t[0][1], minbet()); // betting continues until everyone has folded or called;
        }

        else    t[0].bet(t[0][0], minbet());
        t.print_score();
        //destroy vector of player_in
        //Starts over calling player thats betting as first person
        Sleep(400);
        break;
        */
        case ('h') :
            /* if (t[0].split()){     // if player bets and everyone else has called
            t[0][0].call(t.minbet()); //destroy player_in and recreate it with that player first
            t[0][1].call(t.minbet()); // betting continues until everyone has folded or called;
            }*/
            nextplayer();
            break;
        case ('j') :
            //players[player].fold();
            nextplayer();
            break;
    }
}

void Game::calcWinner (Dealer& dealer) {
    //check for blackjack
    if (dealer.get_blackjack() || dealer.getscore() == 21)	{
        cout << "dealer wins" << endl;
        return;
        //need to add additional component
    }
    int x = 0;
    for (int i = 0; i < player_in.size() - 1; i++) {
        //ask prof adams about overloading bracket twice
        //If a player has a split
        if (get_in (i).split()) {
            for (int j = 1; j < player_in.size() - 1; j++) {
                bool b = get_in (i)[j].get_blackjack();
                if (b) {
                    winners.push_back (&get_in (i));
                    x++;
                }
            }
        }
        bool b = get_in (i)[0].get_blackjack();
        if (b) {
            winners.push_back (&get_in (i));
            x++;
        }
    }
    if (x > 0)
        return;
    else {
        //check for 21
        for (int i = 0; i < player_in.size() - 1; i++)		{
            //If a player has a split
            if (get_in (i).split())			{
                for (int j = 1; j < player_in.size() - 1; j++) {
                    bool b = get_in (i)[j].getscore() == 21;
                    if (b)
                        winners.push_back (&get_in (i));
                }
                bool b = get_in (i)[0].getscore() == 21;
                if (b)
                    winners.push_back (&get_in (i));
            }
        }
    }
    for (int i = 0; i < player_in.size() - 1; i++) {
        if (get_in (i).split()) {
            for (int j = 1; j < player_in.size() - 1; j++) {
                int c = get_in (i)[j].getscore();
                if (dealer.getscore() < c)
                    winners.push_back (&get_in (i));
            }
        }
    }
}

void Player::bet (Hand& h, int& min) {
    bool x = true;
    int f = min;
    Sleep (400);
    while (x) {
        if (-GetAsyncKeyState (38)) {
            f += 10;
            gotoxy (0, 15);
            cout << f;
            Sleep (100);
        }
        if (-GetAsyncKeyState (40)) {
            if (f > 10) f -= 10;
            gotoxy (0, 15);
            cout << f;
            Sleep (100);
        }
        if (-GetAsyncKeyState (71)) {
            money -= f;
            h.bet (f);
            gotoxy (0, 15);
            cout << f;
            min = f;
            x = false;
        }
    }
}

bool Hand::get_blackjack() {
    return blackjack;
}

bool Dealer::get_blackjack() {
    return blackjack;
}

void Hand::is_blackjack() {
    int i;
    for (i = 0; i <= handcard.size() - 1; i++)	{
        if (((handcard[i].get_rank() || handcard[i].get_rank()) == JACK || TEN || KING ||
                QUEEN) &&
                ((handcard[i].get_rank() || handcard[i].get_rank()) == ACE))
            blackjack = true;
    }
}

void Dealer::is_blackjack() {
    int i;
    for (i = 0; i <= dhand.size() - 1; i++)	{
        if (((dhand[i].get_rank() || dhand[i].get_rank()) == JACK || TEN || KING || QUEEN) &&
                ((dhand[i].get_rank() || dhand[i].get_rank()) == ACE))
            blackjack = true;
    }
    if (score > 21)
        bust = true;
}

int Game::num_players() {
    return players.size();
}