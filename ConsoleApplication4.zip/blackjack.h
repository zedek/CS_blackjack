#ifndef BLACKJACK_H
#define BLACKJACK_H

#include <iostream>
#include <Windows.h>
#include <vector>
#include <stdio.h>
#include <ctime>

#include "card.h"
#include "blackjack.h"

using namespace std;

class Deck {
  public:
    Deck();
    Deck (int x);
    void shuffle();
    Card draw_card();
    bool empty();

  private:
    int ndeck;
    vector<Card> cards;
    int top;
};

class Hand {
  public:
    Hand();
    int getrank (int i);
    void setcard (int i, Card& x);
    void total(); // to control  score
    void hit (Deck& d);
    int size();
    int getscore();
    void fold();
    void showhand();
    int bet (int x);
    Card& operator[] (int x);
    int ace;
    bool get_fold();
    bool get_call();
    void showsplit (int x);
    void is_blackjack();
    void call (int min);
    bool get_blackjack();
    //
    void split_back (Card& card);

  private:
    vector<Card> handcard;
    int score;
    bool hascalled;
    bool folded;
    int bet_value;
    bool blackjack;
};
class Dealer { // a hybrid between a player class and hand class, it doesn't
  public:        // need a money pool like a player would.

    Dealer (Deck& d);
    void dtotal();
    void dhit (Deck& d);
    void dealermove (Deck& d);
    void is_blackjack();
    bool get_blackjack();
    int getscore();

  private:
    vector<Card> dhand;  //Dealers hand -- Needs seperate function to calculate total.
    int ace;
    int score;
    bool blackjack;
    bool bust;
};
class Player {
  public:
    Player (Deck& d);
    void splits (vector<Hand>& han, Deck& d); // need both hands to copy the card over.
    vector<Hand>& Player::gethands();
    Hand& operator[] (int x);
    void bet (Hand& h, int& min);
    int size();
    int get_money();
    bool split();
    void showhands();

  private:
    vector<Hand> hands;
    int money;
    bool has_split;
};
class Game {
  public:
    Game (int x);
    void betTurn();
    int winner();
    void nextplayer();
    void print_score();
    void gameHand();
    Player& operator[] (int x);
    bool mode();
    int minbet();
    void calcWinner (Dealer& dealer);
    Player& get_in (int i);
    void nextPlayer();
    bool betting;
    //void test(void (Player::*function)(int, int);
    //

    int num_players();
    Deck du;

  private:
    vector<Player> players;
    vector<Player*> player_in;
    vector<Player*> winners;

    int player = 0;
    int total_bet;

    int min;
    Dealer* dealer;
};

#endif
