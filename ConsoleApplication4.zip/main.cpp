#include <iostream>
#include <ctime>
#include <Windows.h>
#include <vector>
#include "card.h"
#include <stdio.h>
#include "blackjack.h"

using namespace std;

int main() {
    int y;
    cout << "Input number of players:";
    cin >> y;
    system ("cls");
    Game t (y);
    gotoxy (0, 4);
    cout << ">>";
    /*
    t[0][0][1] = t[0][0][0];
    t[0].splits(t[0].gethands(), t.du);
    t[0][0][1] = t[0][0][0];
    */
    t.gameHand();
    while (t.mode()) {
        for (int i = 0; i < y - 1; i++) {
            t.betTurn();
            t.gameHand();
        } t.betting = false;
    }
    // Stuff below this point is for hitting.
    //If a player busts he isn't added to player_in
    /*  int n = 2;

    t.betting = false; // this was just to test the score print
    while (x){
    if (-GetAsyncKeyState(71)){  // used for hitting
    t[0][0].hit(d);     //
    t[0][0][n].display_card(20 + 3 * n, 0, false, true);
    t[0][0].total();
    t.print_score();
    gotoxy(30, 0);
    cout << t[0][0].getscore() << endl;
    n++;
    t.print_score();
    Sleep(400);
    }
    if (-GetAsyncKeyState(72)){ // h for stand
    */
    gotoxy (0, 25);
    return 0;
}